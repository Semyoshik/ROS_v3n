<?php
$name = $_GET['id'];
$x = $_GET['x'];
$y = $_GET['y'];
$tp = $_GET['tp'];


try {
    // подключаемся к серверу
    $conn = new PDO("mysql:host=localhost;dbname=cm22721_usersa", "cm22721_usersa", "root");
}
catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}

try {
    $sql = "UPDATE `FLY` SET `X`= -1, `Y`= -1, `type` = 0 WHERE `id`= 0";
    $affectedRowsNumber = $conn->exec($sql);
}
catch (PDOException $e) {
    echo "Database error: " . $e->getMessage();
}
try {
    $sql = "UPDATE `FLY` SET `X`= -1, `Y`= -1, `type` = 0 WHERE `id`= 1";
    $affectedRowsNumber = $conn->exec($sql);
}
catch (PDOException $e) {
    echo "Database error: " . $e->getMessage();
}
try {
    $sql = "UPDATE `FLY` SET `X`= -1, `Y`= -1, `type` = 0 WHERE `id`= 2";
    $affectedRowsNumber = $conn->exec($sql);
}
catch (PDOException $e) {
    echo "Database error: " . $e->getMessage();
}
try {
    $sql = "UPDATE `FLY` SET `X`= -1, `Y`= -1, `type` = 0 WHERE `id`= 3";
    $affectedRowsNumber = $conn->exec($sql);
}
catch (PDOException $e) {
    echo "Database error: " . $e->getMessage();
}
try {
    $sql = "UPDATE `FLY` SET `X`= -1, `Y`= -1, `type` = 0 WHERE `id`= 4";
    $affectedRowsNumber = $conn->exec($sql);
}
catch (PDOException $e) {
    echo "Database error: " . $e->getMessage();
}