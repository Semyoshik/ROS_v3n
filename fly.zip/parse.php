<?php
$name = $_GET['id'];




try {
    // подключаемся к серверу
    $conn = new PDO("mysql:host=localhost;dbname=cm22721_usersa", "cm22721_usersa", "root");
}
catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}


$sql = "SELECT * FROM FLY WHERE id = :name";
   $stmt = $conn->prepare($sql);
        // привязываем значение параметра :userid к $_GET["id"]
        $stmt->bindValue(":name", 0);
        // выполняем выражение и получаем пользователя по id
        $stmt->execute();
        if($stmt->rowCount() > 0){
            foreach ($stmt as $row) {
              $idd0 = $row["name"];
              $X0 = $row["X"];
              $Y0 = $row["Y"];
              $tp0 = $row["type"];
            }
        }
        else{
            echo "USER ERROR";
        }


$sql = "SELECT * FROM FLY WHERE id = :name";
   $stmt = $conn->prepare($sql);
        // привязываем значение параметра :userid к $_GET["id"]
        $stmt->bindValue(":name", 1);
        // выполняем выражение и получаем пользователя по id
        $stmt->execute();
        if($stmt->rowCount() > 0){
            foreach ($stmt as $row) {
              $idd1 = $row["name"];
              $X1 = $row["X"];
              $Y1 = $row["Y"];
              $tp1 = $row["type"];
            }
        }
        else{
            echo "USER ERROR";
        }

$sql = "SELECT * FROM FLY WHERE id = :name";
   $stmt = $conn->prepare($sql);
        // привязываем значение параметра :userid к $_GET["id"]
        $stmt->bindValue(":name", 2);
        // выполняем выражение и получаем пользователя по id
        $stmt->execute();
        if($stmt->rowCount() > 0){
            foreach ($stmt as $row) {
              $idd2 = $row["name"];
              $X2 = $row["X"];
              $Y2 = $row["Y"];
              $tp2 = $row["type"];
            }
        }
        else{
            echo "USER ERROR";
        }

$sql = "SELECT * FROM FLY WHERE id = :name";
   $stmt = $conn->prepare($sql);
        // привязываем значение параметра :userid к $_GET["id"]
        $stmt->bindValue(":name", 3);
        // выполняем выражение и получаем пользователя по id
        $stmt->execute();
        if($stmt->rowCount() > 0){
            foreach ($stmt as $row) {
              $idd3 = $row["name"];
              $X3 = $row["X"];
              $Y3 = $row["Y"];
              $tp3 = $row["type"];
            }
        }
        else{
            echo "USER ERROR";
        }
$sql = "SELECT * FROM FLY WHERE id = :name";
   $stmt = $conn->prepare($sql);
        // привязываем значение параметра :userid к $_GET["id"]
        $stmt->bindValue(":name", 4);
        // выполняем выражение и получаем пользователя по id
        $stmt->execute();
        if($stmt->rowCount() > 0){
            foreach ($stmt as $row) {
              $idd4 = $row["name"];
              $X4 = $row["X"];
              $Y4 = $row["Y"];
              $tp4 = $row["type"];
            }
        }
        else{
            echo "USER ERROR";
        }

header('Location: index.html?X1=' . $X1 . '&Y1=' . $Y1 . '&tp1=' . $tp1 . '&X2=' . $X2 . '&Y2=' . $Y2 . '&tp2=' . $tp2 . '&X3=' . $X3 . '&Y3=' . $Y3 . '&tp3=' . $tp3 . '&X4=' . $X4 . '&Y4=' . $Y4 . '&tp4=' . $tp4 . '&X0=' . $X0 . '&Y0=' . $Y0 . '&tp0=' . $tp0);