<?php
$name = $_GET['id'];
$x = $_GET['x'];
$y = $_GET['y'];
$tp = $_GET['tp'];


try {
    // подключаемся к серверу
    $conn = new PDO("mysql:host=localhost;dbname=cm22721_usersa", "cm22721_usersa", "root");
}
catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
try {
    $sql = "UPDATE `FLY` SET `X`= $x, `Y`= $y, `type` = $tp WHERE `id`= $name";
    $affectedRowsNumber = $conn->exec($sql);
}
catch (PDOException $e) {
    echo "Database error: " . $e->getMessage();
}